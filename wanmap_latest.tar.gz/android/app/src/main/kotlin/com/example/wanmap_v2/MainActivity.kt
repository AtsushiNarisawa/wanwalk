package com.example.wanmap_v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
